import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {PlacesService} from './../home/places.service';

@Component({
  selector: 'app-locator',
  templateUrl: './locator.page.html',
  styleUrls: ['./locator.page.scss'],
})
export class LocatorPage implements OnInit {
  homeLoc:string = '';

  constructor(private router: Router, private placesservice: PlacesService) { }

  ngOnInit() {
  }

  onGetHomeLocation(homeLocation,workLocation) {
    this.placesservice.homeLocation = homeLocation.viewModel;
    this.placesservice.workLocation = workLocation.viewModel;
    
    this.router.navigateByUrl('home/tabs/places')
  }
}

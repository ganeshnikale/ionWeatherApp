import { UtcConverterPipe } from './utc-converter.pipe';

describe('UtcConverterPipe', () => {
  it('create an instance', () => {
    const pipe = new UtcConverterPipe();
    expect(pipe).toBeTruthy();
  });
});

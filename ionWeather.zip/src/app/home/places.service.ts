import { WeatherService } from './WeatherService';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';



@Injectable({
	providedIn: 'root'
})
export class PlacesService {



	workLocation: string = '';

	homeLocation: string = ''


	constructor(private http: HttpClient, private weatherservice: WeatherService) { }

	getLatLongs(location:string) {
		
		return this.http.get(`https://maps.googleapis.com/maps/api/geocode/json?address=${location}&key=AIzaSyADtYqSYIWJ5ZBU160TZH6rkLkhK_vboh8`)
	}

	getPlaces1(lat, lng, lookingfor) {
		let params = new HttpParams()
		.set("type", lookingfor)
		.set("key", "AIzaSyADtYqSYIWJ5ZBU160TZH6rkLkhK_vboh8");
		return this.http.get(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=1500`,{params})
	}

	getPlaceDetails(place_id:string) {
		let params = new HttpParams()
		.set("place_id", place_id)
		.append("fields","name,opening_hours,photos,rating,formatted_phone_number,formatted_address,website,reference")
		.set("key", "AIzaSyADtYqSYIWJ5ZBU160TZH6rkLkhK_vboh8");
		return this.http.get(`https://maps.googleapis.com/maps/api/place/details/json?`,{params})
	}

}
